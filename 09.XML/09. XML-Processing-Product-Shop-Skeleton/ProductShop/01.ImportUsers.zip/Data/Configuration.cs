﻿namespace ProductShop.Data
{
    public class Configuration
    {
        public const string ConectionString = "Server=EXECUTOR;Database=ProductShop;Integrated Security=True";
    }
}
