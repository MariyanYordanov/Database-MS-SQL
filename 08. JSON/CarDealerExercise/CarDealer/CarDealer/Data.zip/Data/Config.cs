﻿namespace CarDealer.Data
{
    public static class Config
    {
        public const string ConnectionString = "Server=EXECUTOR;Database=CarDealer;Trusted_Connection=True;";
    }
}
