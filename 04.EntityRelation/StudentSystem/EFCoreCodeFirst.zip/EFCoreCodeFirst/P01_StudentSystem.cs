﻿namespace P01_StudentSystem
{
    public class P01_StudentSystem
    {
        static void Main(string[] args)
        {
            
        }
    }
}
