﻿namespace P03_FootballBetting
{
    using System;

    internal class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
